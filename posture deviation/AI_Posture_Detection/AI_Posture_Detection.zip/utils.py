"""
============================================================
utils.py - Simplified Posture Detection Utilities
============================================================
Provides helper functions for model prediction, CSV logging,
session statistics tracking, and FPS calculation.
"""
import os
import csv
import pickle
import time
import datetime
import pandas as pd

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()

MODELS_DIR  = os.path.join(BASE_DIR, "models")
HISTORY_CSV = os.path.join(BASE_DIR, "posture_history.csv")

# 1. Model Loading
def load_model_artifacts():
    model_path = os.path.join(MODELS_DIR, "posture_model.pkl")
    scaler_path = os.path.join(MODELS_DIR, "scaler.pkl")
    
    if not os.path.exists(model_path) or not os.path.exists(scaler_path):
        return None, None
        
    with open(model_path, "rb") as f:
        model = pickle.load(f)
    with open(scaler_path, "rb") as f:
        scaler = pickle.load(f)
        
    return model, scaler

# 2. Prediction
def predict_posture(model, scaler, feature_vector):
    if model is None or scaler is None:
        return 1, 1.0  # fallback: Good Posture
    
    # Scale feature vector and predict
    X = feature_vector.reshape(1, -1)
    X_scaled = scaler.transform(X)
    
    label = model.predict(X_scaled)[0]
    
    # Estimate confidence
    if hasattr(model, "predict_proba"):
        confidence = float(model.predict_proba(X_scaled)[0].max())
    else:
        confidence = 0.95
        
    return int(label), confidence

# 3. CSV Posture History Logging
def init_history_csv():
    if not os.path.exists(HISTORY_CSV):
        headers = ["timestamp", "date", "time", "posture_label", "posture_text", "confidence", "neck_angle", "spine_angle", "shoulder_slope"]
        with open(HISTORY_CSV, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)

def log_posture_to_csv(posture_text, confidence, angles_dict):
    init_history_csv()
    try:
        now = datetime.datetime.now()
        row = [
            now.isoformat(),
            now.strftime("%Y-%m-%d"),
            now.strftime("%H:%M:%S"),
            0 if "BAD" in posture_text else 1,
            posture_text,
            round(confidence, 4),
            angles_dict.get("neck_avg", 0),
            angles_dict.get("spine_angle", 0),
            angles_dict.get("shoulder_slope", 0)
        ]
        with open(HISTORY_CSV, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(row)
    except Exception as e:
        print(f"[ERROR] Failed to log to CSV: {e}")

def load_posture_history():
    if os.path.exists(HISTORY_CSV):
        return pd.read_csv(HISTORY_CSV)
    return pd.DataFrame()

# 4. Real-time FPS Calculator
class FPSCounter:
    def __init__(self):
        self.prev_time = time.time()
        self.fps = 0.0
        
    def update(self) -> float:
        now = time.time()
        delta = now - self.prev_time
        self.prev_time = now
        instant_fps = 1.0 / (delta + 1e-6)
        self.fps = 0.9 * self.fps + 0.1 * instant_fps
        return round(self.fps, 1)

# 5. Real-time Session Statistics
class SessionStats:
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.total_frames = 0
        self.good_frames = 0
        self.bad_frames = 0
        self.start_time = time.time()
        
    def update(self, is_good: bool):
        self.total_frames += 1
        if is_good:
            self.good_frames += 1
        else:
            self.bad_frames += 1
            
    @property
    def session_duration(self) -> float:
        return round(time.time() - self.start_time, 1)
        
    @property
    def good_posture_pct(self) -> float:
        if self.total_frames == 0:
            return 0.0
        return round(100.0 * self.good_frames / self.total_frames, 1)

    @property
    def bad_posture_pct(self) -> float:
        if self.total_frames == 0:
            return 0.0
        return round(100.0 * self.bad_frames / self.total_frames, 1)
        
    def summary(self) -> dict:
        return {
            "session_duration": self.session_duration,
            "total_frames": self.total_frames,
            "good_posture_pct": self.good_posture_pct,
            "bad_posture_pct": self.bad_posture_pct
        }
