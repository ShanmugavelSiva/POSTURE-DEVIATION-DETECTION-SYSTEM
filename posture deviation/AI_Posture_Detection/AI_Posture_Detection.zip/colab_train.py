"""
============================================================
colab_train.py - Self-Contained Google Colab Training Script
============================================================
This script is completely independent.
How to use in Google Colab:
1. Upload "sitting_features.csv" directly to Colab's file storage.
2. Copy and paste this code into a Colab cell.
3. Run the cell to train the model and save the pickles!
"""
import os
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# 1. Feature columns expected by real-time detector
FEATURE_COLS = [
    "neck_avg", "spine_angle", "shoulder_slope", "head_tilt",
    "hip_alignment", "ear_sh_left", "ear_sh_right",
    "lm7_x",  "lm7_y",   # left ear
    "lm8_x",  "lm8_y",   # right ear
    "lm11_x", "lm11_y",  # left shoulder
    "lm12_x", "lm12_y",  # right shoulder
    "lm23_x", "lm23_y",  # left hip
    "lm24_x", "lm24_y",  # right hip
]

def train_on_colab():
    csv_file = "sitting_features.csv"
    
    if not os.path.exists(csv_file):
        print(f"ERROR: '{csv_file}' not found!")
        print("Please upload the 'sitting_features.csv' file using the file panel on the left side of Colab.")
        return
        
    print("=== LOADING DATASET ===")
    df = pd.read_csv(csv_file)
    print(f"Successfully loaded {len(df)} samples.")
    print(f"Good posture (1) samples: {(df['label'] == 1).sum()}")
    print(f"Bad posture (0) samples : {(df['label'] == 0).sum()}")
    
    # Extract features and labels
    X = df[FEATURE_COLS].values
    y = df["label"].values
    
    # Split into train (80%) and test (20%)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print("\n=== TRAINING RANDOM FOREST MODEL ===")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    
    print("\n========================================")
    print(f"MODEL ACCURACY ON COLAB: {accuracy * 100:.2f}%")
    print("========================================")
    
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["Bad Posture", "Good Posture"]))
    
    # Save pickle files
    print("\n=== SAVING PICKLE MODELS ===")
    with open("posture_model.pkl", "wb") as f:
        pickle.dump(model, f)
    with open("scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
        
    # Save a simple model info dictionary
    model_info = {
        "model_name": "Random Forest",
        "accuracy": accuracy,
        "feature_names": FEATURE_COLS,
        "label_names": ["bad", "good"]
    }
    with open("model_info.pkl", "wb") as f:
        pickle.dump(model_info, f)
        
    print("Saved: posture_model.pkl")
    print("Saved: scaler.pkl")
    print("Saved: model_info.pkl")
    print("Training complete! You can now download these pickle files from Colab.")

if __name__ == "__main__":
    train_on_colab()
