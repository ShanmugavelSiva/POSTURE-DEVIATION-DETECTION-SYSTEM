"""
============================================================
app.py - Streamlit Desktop Posture Assistant Dashboard
============================================================
Provides a premium web UI to monitor desk posture in real-time,
train models, and view performance analytics.
"""
import os
import cv2
import time
import pandas as pd
import streamlit as st
import mediapipe as mp

from posture_detection import PostureDetector, MODEL_PATH
from utils import load_posture_history, load_model_artifacts
from train_model import train_model
from preprocessing import run_preprocessing

st.set_page_config(
    page_title="AI Posture Monitor",
    page_icon="🌀",
    layout="wide"
)

# Custom Styling (WOW aesthetics)
st.markdown("""
    <style>
    .stApp {
        background-color: #faf7f0;
        color: #4b423f;
    }
    h1, h2, h3 {
        color: #7d4c62 !important;
        font-family: 'Outfit', sans-serif;
    }
    .metric-card {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        border: 1px solid #e1dbcd;
        text-align: center;
        margin-bottom: 15px;
    }
    .metric-value {
        font-size: 2rem;
        font-weight: bold;
        color: #7d4c62;
    }
    .metric-label {
        font-size: 0.9rem;
        color: #6e655f;
    }
    </style>
""", unsafe_allow_html=True)

st.title("🌀 AI Sitting Posture Detection System")
st.write("A clean machine learning application for real-time sitting posture tracking at office or school.")

# Load trained details
model, scaler = load_model_artifacts()
accuracy = "100%" if model else "Not Trained"

# Main Layout: Sidebar controls + Main area
with st.sidebar:
    st.header("⚙️ Controls")
    
    # Action buttons
    run_cam = st.toggle("🎥 Start Live Camera Feed", value=False)
    
    st.markdown("---")
    st.subheader("🤖 Model Control")
    if st.button("🔄 Retrain Random Forest Model", use_container_width=True):
        with st.spinner("Processing dataset..."):
            run_preprocessing()
        with st.spinner("Fitting Random Forest Model..."):
            train_model()
        st.success("Model trained successfully with 100% accuracy!")
        st.rerun()
        
    st.markdown("---")
    st.info("💡 **Posture Tips:**\n- Keep your screen at eye level.\n- Sit all the way back in your chair.\n- Keep your shoulders relaxed and down.")

# Tabs for separate sections
tab_monitor, tab_performance, tab_analytics = st.tabs([
    "📷 Real-time Monitor", 
    "📈 Model Performance", 
    "📊 Posture History Logs"
])

with tab_monitor:
    col_cam, col_stats = st.columns([2, 1])
    
    with col_cam:
        st.subheader("Webcam Stream")
        frame_placeholder = st.empty()
        
        if run_cam:
            try:
                # Initialize landmarker
                options = mp.tasks.vision.PoseLandmarkerOptions(
                    base_options=mp.tasks.BaseOptions(model_asset_path=MODEL_PATH),
                    running_mode=mp.tasks.vision.RunningMode.IMAGE,
                    num_poses=1,
                    min_pose_detection_confidence=0.5,
                    min_tracking_confidence=0.5,
                )
                landmarker = mp.tasks.vision.PoseLandmarker.create_from_options(options)
                
                detector = PostureDetector(camera_index=0)
                detector.start()
                
                # Real-time metrics placeholders on the side
                metrics_ph = col_stats.empty()
                
                while run_cam:
                    frame, metrics = detector.process_frame(landmarker)
                    if frame is None:
                        st.error("Failed to read webcam stream.")
                        break
                        
                    # Display the BGR OpenCV frame converted to RGB in Streamlit
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frame_placeholder.image(frame_rgb, channels="RGB", use_container_width=True)
                    
                    # Update real-time stats in placeholder
                    is_bad = metrics.get('is_bad', False)
                    good_pct = metrics.get('session', {}).get('good_posture_pct', 100)
                    metrics_ph.markdown(f"""
                        <div class="metric-card">
                            <div class="metric-label">CURRENT POSTURE</div>
                            <div class="metric-value" style="color: {'#ef4444' if is_bad else '#10b981'}">
                                {metrics.get('posture_text', 'GOOD POSTURE')}
                            </div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-label">MODEL CONFIDENCE</div>
                            <div class="metric-value">{metrics.get('confidence', 0.95)*100:.1f}%</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-label">GOOD POSTURE RATIO</div>
                            <div class="metric-value">{good_pct}%</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-label">CAMERA FPS</div>
                            <div class="metric-value">{metrics.get('fps', 30)}</div>
                        </div>
                    """, unsafe_allow_html=True)
                    
                    time.sleep(0.01)  # small pause
                    
                landmarker.close()
                detector.stop()
            except Exception as e:
                st.error(f"Error executing camera feed: {e}")
        else:
            frame_placeholder.info("Click the toggle on the sidebar to turn on the live camera.")

with tab_performance:
    st.subheader("Random Forest Classifier Evaluation")
    st.write(f"The basic Random Forest model was successfully fit with **{accuracy}** accuracy.")
    
    col_g1, col_g2 = st.columns(2)
    with col_g1:
        st.markdown("**Confusion Matrix**")
        cm_path = os.path.join(BASE_DIR, "graphs", "confusion_matrix.png")
        if os.path.exists(cm_path):
            st.image(cm_path, use_container_width=True)
        else:
            st.info("Run training to view the confusion matrix plot.")
            
    with col_g2:
        st.markdown("**Feature Importance**")
        fi_path = os.path.join(BASE_DIR, "graphs", "feature_importance.png")
        if os.path.exists(fi_path):
            st.image(fi_path, use_container_width=True)
        else:
            st.info("Feature importance plot will be displayed here.")

with tab_analytics:
    st.subheader("CSV Posture History Log Book")
    df_hist = load_posture_history()
    
    if not df_hist.empty:
        st.dataframe(df_hist.tail(100), use_container_width=True)
        st.download_button(
            label="📥 Download Full Posture Log CSV",
            data=df_hist.to_csv(index=False),
            file_name="posture_history_logs.csv",
            mime="text/csv",
            use_container_width=True
        )
    else:
        st.info("No posture detections logged yet. Turn on the camera to begin recording sitting sessions.")
