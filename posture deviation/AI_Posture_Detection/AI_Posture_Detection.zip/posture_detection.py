"""
============================================================
posture_detection.py - Simplified Posture Detection Engine
============================================================
Captures video from the webcam, processes body landmarks using
MediaPipe, computes posture features, and uses the trained
Random Forest model to classify posture as Good or Bad in real-time.
"""
import os
import cv2
import math
import time
import numpy as np
import mediapipe as mp

from feature_extraction import extract_features_realtime
from utils import load_model_artifacts, predict_posture, log_posture_to_csv, FPSCounter, SessionStats

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()

MODEL_PATH = os.path.join(BASE_DIR, "models", "pose_landmarker_lite.task")

# Colors
COLOR_GOOD = (0, 220, 80)    # Green
COLOR_BAD  = (0, 50, 220)    # Red
COLOR_WARN = (0, 200, 255)   # Orange (warnings)

# MediaPipe Pose Landmarker Adapter
BaseOptions = mp.tasks.BaseOptions
PoseLandmarker = mp.tasks.vision.PoseLandmarker
PoseLandmarkerOpts = mp.tasks.vision.PoseLandmarkerOptions
RunningMode = mp.tasks.vision.RunningMode

class LandmarkAdapter:
    """Wraps a landmark coordinate for feature extraction."""
    def __init__(self, lm):
        self.x = lm.x
        self.y = lm.y
        self.z = lm.z
        self.visibility = getattr(lm, "visibility", 1.0)

def draw_skeleton(frame, landmarks, color):
    """Draws major posture lines on the skeleton."""
    h, w = frame.shape[:2]
    connections = [(11, 12), (11, 23), (12, 24), (23, 24), (7, 11), (8, 12)]
    
    for i, j in connections:
        pt1 = (int(landmarks[i].x * w), int(landmarks[i].y * h))
        pt2 = (int(landmarks[j].x * w), int(landmarks[j].y * h))
        cv2.line(frame, pt1, pt2, color, 2, cv2.LINE_AA)
        
    for idx in [7, 8, 11, 12, 23, 24]:
        px = (int(landmarks[idx].x * w), int(landmarks[idx].y * h))
        cv2.circle(frame, px, 6, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.circle(frame, px, 5, color, -1, cv2.LINE_AA)

def draw_angle_lines(frame, landmarks):
    """Draws vertical alignment guides for spine and neck."""
    h, w = frame.shape[:2]
    ls = (int(landmarks[11].x * w), int(landmarks[11].y * h))
    rs = (int(landmarks[12].x * w), int(landmarks[12].y * h))
    lh = (int(landmarks[23].x * w), int(landmarks[23].y * h))
    rh = (int(landmarks[24].x * w), int(landmarks[24].y * h))
    
    sh_mid = ((ls[0] + rs[0]) // 2, (ls[1] + rs[1]) // 2)
    hi_mid = ((lh[0] + rh[0]) // 2, (lh[1] + rh[1]) // 2)
    
    # Spine center line
    cv2.line(frame, sh_mid, hi_mid, COLOR_GOOD, 2, cv2.LINE_AA)
    
    # Verticals
    vert_top = (sh_mid[0], max(0, sh_mid[1] - 100))
    cv2.line(frame, sh_mid, vert_top, (180, 180, 180), 1, cv2.LINE_AA)

def draw_hud(frame, posture_text, confidence, angles, fps, session_stats, is_bad):
    """Draws a beautiful head-up display on top of the webcam feed."""
    h, w = frame.shape[:2]
    border_color = COLOR_BAD if is_bad else COLOR_GOOD
    
    # Border
    cv2.rectangle(frame, (0, 0), (w-1, h-1), border_color, 4)
    
    # Info Panel Background
    cv2.rectangle(frame, (5, 5), (280, 42), (10, 10, 20), -1)
    
    # Text angles display
    neck_angle = int(angles.get("neck_avg", 0))
    torso_angle = int(angles.get("spine_angle", 0))
    
    cv2.putText(frame, f"Neck: {neck_angle}deg", (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Torso: {torso_angle}deg", (145, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)
    
    # Status Overlay bottom bar
    cv2.rectangle(frame, (0, h-45), (w, h), (15, 15, 25), -1)
    
    # Draw posture text and confidence
    p_color = COLOR_BAD if is_bad else COLOR_GOOD
    cv2.putText(frame, posture_text, (15, h-15), cv2.FONT_HERSHEY_SIMPLEX, 0.7, p_color, 2, cv2.LINE_AA)
    cv2.putText(frame, f"Model: Random Forest | Confidence: {confidence*100:.1f}%", (w//2-160, h-17), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1, cv2.LINE_AA)
    cv2.putText(frame, f"FPS: {fps}", (w-85, h-17), cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_WARN, 1, cv2.LINE_AA)

class PostureDetector:
    def __init__(self, camera_index=0):
        self.camera_index = camera_index
        self.fps_counter = FPSCounter()
        self.session_stats = SessionStats()
        
        self.model, self.scaler = load_model_artifacts()
        self.cap = None
        self.running = False
        
    def start(self):
        self.cap = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.running = True
        self.session_stats.reset()
        
    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()
            
    def process_frame(self, landmarker):
        ret, frame = self.cap.read()
        if not ret:
            return None, {}
            
        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        fps = self.fps_counter.update()
        
        # 1. Convert frame for MediaPipe Tasks API
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = landmarker.detect(mp_image)
        
        # 2. Re-map landmarks
        if not result.pose_landmarks or len(result.pose_landmarks) == 0:
            cv2.putText(frame, "No Person Detected", (w//2-130, h//2), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (100, 100, 100), 2)
            return frame, {"posture_text": "No Person", "no_person": True}
            
        raw_lms = result.pose_landmarks[0]
        landmarks = [LandmarkAdapter(lm) for lm in raw_lms]
        
        # 3. Extract standard features
        feat_vec, angles = extract_features_realtime(landmarks, w, h)
        
        # 4. Predict posture using Random Forest model
        label, confidence = predict_posture(self.model, self.scaler, feat_vec)
        is_bad = (label == 0)
        posture_text = "BAD POSTURE" if is_bad else "GOOD POSTURE"
        
        # 5. Log prediction history (every 30 frames ≈ 1 second)
        if int(time.time()) % 2 == 0:
            log_posture_to_csv(posture_text, confidence, angles)
            
        # Update session statistics
        self.session_stats.update(is_good=not is_bad)
        
        # 6. Draw HUD overlays
        skel_color = COLOR_BAD if is_bad else COLOR_GOOD
        draw_skeleton(frame, landmarks, skel_color)
        draw_angle_lines(frame, landmarks)
        draw_hud(frame, posture_text, confidence, angles, fps, self.session_stats, is_bad)
        
        metrics = {
            "posture_text": posture_text,
            "is_bad": is_bad,
            "confidence": confidence,
            "neck_avg": angles.get("neck_avg", 0),
            "spine_angle": angles.get("spine_angle", 0),
            "shoulder_slope": angles.get("shoulder_slope", 0),
            "fps": fps,
            "session": self.session_stats.summary(),
            "no_person": False
        }
        
        return frame, metrics

    def run_window(self):
        """Standard window execution for quick local testing."""
        options = PoseLandmarkerOpts(
            base_options=BaseOptions(model_asset_path=MODEL_PATH),
            running_mode=RunningMode.IMAGE,
            num_poses=1,
            min_pose_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        landmarker = PoseLandmarker.create_from_options(options)
        
        self.start()
        print("[Detector] Starting. Press 'q' to quit.")
        
        while self.cap.isOpened():
            frame, metrics = self.process_frame(landmarker)
            if frame is None:
                break
                
            cv2.imshow("Sitting Posture Detector", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        landmarker.close()
        self.stop()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    detector = PostureDetector()
    detector.run_window()
