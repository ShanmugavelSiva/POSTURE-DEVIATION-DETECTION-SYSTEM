"""
============================================================
train_model.py - Simplified Posture Classifier Training
============================================================
Loads preprocessed training data, fits a basic Random Forest
classifier, prints evaluation metrics, and saves the trained
model and scaler for real-time predictions.
"""
import os
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from preprocessing import run_preprocessing, FEATURE_COLS

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()

MODELS_DIR = os.path.join(BASE_DIR, "models")
GRAPHS_DIR = os.path.join(BASE_DIR, "graphs")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
SITTING_DIR = os.path.join(BASE_DIR, "dataset", "sitting")

for d in [MODELS_DIR, GRAPHS_DIR, REPORTS_DIR]:
    os.makedirs(d, exist_ok=True)

def train_model():
    print("\n=== STARTING MODEL TRAINING ===")
    
    # 1. Load train and test splits
    train_path = os.path.join(SITTING_DIR, "sitting_train.csv")
    test_path  = os.path.join(SITTING_DIR, "sitting_test.csv")
    
    if not os.path.exists(train_path) or not os.path.exists(test_path):
        run_preprocessing()
        
    train_df = pd.read_csv(train_path)
    test_df  = pd.read_csv(test_path)
    
    # 2. Extract feature arrays and labels
    X_train = train_df[FEATURE_COLS].values
    y_train = train_df["label"].values
    
    X_test  = test_df[FEATURE_COLS].values
    y_test  = test_df["label"].values
    
    # 3. Scale the features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)
    
    # 4. Train the basic model (Random Forest)
    print("     Training Random Forest Classifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # 5. Evaluate the model
    y_pred = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)
    print(f"\n     ========================================")
    print(f"     MODEL ACCURACY: {acc * 100:.2f}%")
    print(f"     ========================================\n")
    
    # Print clean classification report
    print("Classification Report:")
    print(classification_report(y_test, y_pred, target_names=["Bad Posture", "Good Posture"]))
    
    # 6. Generate confusion matrix graph (highly visual for presentations!)
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", 
                xticklabels=["Bad Posture", "Good Posture"], 
                yticklabels=["Bad Posture", "Good Posture"])
    plt.ylabel("Actual Label")
    plt.xlabel("Predicted Label")
    plt.title(f"Confusion Matrix (Accuracy: {acc * 100:.2f}%)")
    
    cm_path = os.path.join(GRAPHS_DIR, "confusion_matrix.png")
    plt.savefig(cm_path, bbox_inches="tight")
    plt.close()
    print(f"     Saved Confusion Matrix: {cm_path}")
    
    # 7. Save model and scaler objects (pickle)
    model_path = os.path.join(MODELS_DIR, "posture_model.pkl")
    scaler_path = os.path.join(MODELS_DIR, "scaler.pkl")
    info_path = os.path.join(MODELS_DIR, "model_info.pkl")
    
    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    with open(scaler_path, "wb") as f:
        pickle.dump(scaler, f)
    
    # Save simple dictionary with info
    model_info = {
        "model_name": "Random Forest",
        "accuracy": acc,
        "feature_names": FEATURE_COLS,
        "label_names": ["bad", "good"]
    }
    with open(info_path, "wb") as f:
        pickle.dump(model_info, f)
        
    print("=== MODEL TRAINING COMPLETE ===\n")

if __name__ == "__main__":
    train_model()
