"""
============================================================
preprocessing.py - Simplified Sitting Posture Preprocessor
============================================================
Processes the raw office/school sitting dataset (confidence_features.csv)
and prepares train/test splits for the machine learning model.
"""
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()

RAW_DIR = os.path.join(BASE_DIR, "dataset", "raw")
SITTING_DIR = os.path.join(BASE_DIR, "dataset", "sitting")
os.makedirs(SITTING_DIR, exist_ok=True)

# Standard features expected by model
FEATURE_COLS = [
    "neck_avg", "spine_angle", "shoulder_slope", "head_tilt",
    "hip_alignment", "ear_sh_left", "ear_sh_right",
    "lm7_x",  "lm7_y",   # left ear
    "lm8_x",  "lm8_y",   # right ear
    "lm11_x", "lm11_y",  # left shoulder
    "lm12_x", "lm12_y",  # right shoulder
    "lm23_x", "lm23_y",  # left hip
    "lm24_x", "lm24_y",  # right hip
]

def run_preprocessing():
    print("\n=== STARTING SITTING DATASET PREPROCESSING ===")
    
    # 1. Load the raw confidence features sitting dataset
    raw_path = os.path.join(RAW_DIR, "confidence_features.csv")
    df = pd.read_csv(raw_path)
    
    # 2. Map posture labels: Upright/Stiff = 1 (Good posture), Slouched = 0 (Bad posture)
    posture_map = {"Upright": 1, "Stiff": 1, "Slouched": 0}
    df["label"] = df["posture"].map(posture_map)
    df = df.dropna(subset=["label"])
    df["label"] = df["label"].astype(int)
    
    # 3. Construct standard feature columns
    feat_df = pd.DataFrame()
    
    feat_df["spine_angle"]    = df["spine_angle"].values
    feat_df["shoulder_slope"] = df["shoulder_slope"].values
    feat_df["head_tilt"]      = df["head_tilt_angle"].values
    
    # Approximate neck angles and distances based on posture ratios
    feat_df["neck_avg"]       = df["eye_shoulder_y_ratio"].values * 45.0
    feat_df["hip_alignment"]  = df["shoulder_y_diff"].abs().values * 20.0
    feat_df["ear_sh_left"]    = df["hip_shoulder_y_diff"].abs().values * 0.5
    feat_df["ear_sh_right"]   = df["hip_shoulder_y_diff"].abs().values * 0.5
    
    # Reconstruct landmark coordinates
    feat_df["lm11_x"] = df["shoulder_center_x"].values
    feat_df["lm11_y"] = df["shoulder_y_diff"].values * 0.5
    feat_df["lm12_x"] = df["shoulder_center_x"].values
    feat_df["lm12_y"] = -df["shoulder_y_diff"].values * 0.5
    feat_df["lm23_x"] = df["hip_center_x"].values
    feat_df["lm23_y"] = df["hip_shoulder_y_diff"].values * 0.5 + 0.6
    feat_df["lm24_x"] = df["hip_center_x"].values
    feat_df["lm24_y"] = df["hip_shoulder_y_diff"].values * 0.5 + 0.6
    
    feat_df["lm7_x"]  = df["shoulder_center_x"].values - df["body_lean_x"].values
    feat_df["lm7_y"]  = feat_df["lm11_y"] - feat_df["ear_sh_left"]
    feat_df["lm8_x"]  = df["shoulder_center_x"].values + df["body_lean_x"].values
    feat_df["lm8_y"]  = feat_df["lm12_y"] - feat_df["ear_sh_right"]
    
    feat_df["label"]  = df["label"].values
    feat_df["source"] = "confidence_features"
    
    # Drop rows containing NaNs
    feat_df = feat_df.dropna()
    
    # 4. Split dataset into train (80%) and test (20%) sets
    train_df, test_df = train_test_split(
        feat_df, test_size=0.2, random_state=42, stratify=feat_df["label"]
    )
    
    # 5. Save output CSV files
    sitting_path = os.path.join(SITTING_DIR, "sitting_features.csv")
    train_path = os.path.join(SITTING_DIR, "sitting_train.csv")
    test_path = os.path.join(SITTING_DIR, "sitting_test.csv")
    
    feat_df.to_csv(sitting_path, index=False)
    train_df.to_csv(train_path, index=False)
    test_df.to_csv(test_path, index=False)
    
    print(f"     Cleaned samples : {len(feat_df)}")
    print(f"     Train split size: {len(train_df)}")
    print(f"     Test split size : {len(test_df)}")
    print("=== PREPROCESSING COMPLETE ===\n")
    
    return {
        "train_path": train_path,
        "test_path": test_path,
        "feature_cols": FEATURE_COLS
    }

if __name__ == "__main__":
    run_preprocessing()
